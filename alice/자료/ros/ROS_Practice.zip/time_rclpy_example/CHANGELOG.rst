^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package time_rclpy_example
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.6.0 (2021-04-20)
------------------
* Modified script_dir and install_scripts of setup.cfg file
* Contributors: Darby Lim

0.5.0 (2021-03-04)
------------------

0.4.0 (2021-02-22)
------------------
* Added new ROS 2 example package using rclpy's time functions for ROS 2 seminar
* Contributors: Darby Lim
