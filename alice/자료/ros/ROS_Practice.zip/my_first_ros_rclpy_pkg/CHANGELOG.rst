^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package my_first_ros_rclpy_pkg
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.6.0 (2021-04-20)
------------------
* Modified script_dir and install_scripts of setup.cfg file
* Contributors: Darby Lim

0.5.0 (2021-03-04)
------------------

0.4.0 (2021-02-22)
------------------

0.3.0 (2021-01-28)
------------------

0.2.0 (2021-01-06)
------------------
* Added ROS 2 basic package using rclpy for ROS 2 seminar
* Contributors: Pyo, Darby Lim
